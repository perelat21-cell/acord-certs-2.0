import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Download, Loader2, BookmarkPlus, RotateCcw, ShieldCheck, Building2, Files, Stamp, Wand2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { PageTitle, Panel } from "@/components/AppShell";
import { DropZone } from "@/components/DropZone";
import { ReportView } from "@/components/ReportView";
import {
  generateCertificate,
  getCertificate,
  listSavedDocs,
  listTemplates,
  saveDocuments,
  type CertReport,
} from "@/lib/cert.functions";
import { safeName, uploadFile } from "@/lib/upload";

export const Route = createFileRoute("/")({
  validateSearch: (s: Record<string, unknown>): { edit?: string } => (typeof s["edit"] === "string" ? { edit: s["edit"] } : {}),
  head: () => ({
    meta: [
      { title: "New certificate — Certify" },
      { name: "description", content: "Upload a certificate request and policies to get a completed ACORD certificate." },
      { property: "og:title", content: "New certificate — Certify" },
      { property: "og:description", content: "Upload a certificate request and policies to get a completed ACORD certificate." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: NewCertificate,
});

type Uploaded = { path: string; name: string; mime: string; role: "request" | "insurance" };
type Result = { id: string; url: string | null; sampleUrl: string | null; insured: string; holder: string; report: CertReport };
type Workflow = "certificate" | "application";

function NewCertificate() {
  const [requestText, setRequestText] = useState("");
  const [requestFiles, setRequestFiles] = useState<File[]>([]);
  const [insFiles, setInsFiles] = useState<File[]>([]);
  const [savedIds, setSavedIds] = useState<string[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [result, setResult] = useState<Result | null>(null);
  const [uploaded, setUploaded] = useState<Uploaded[]>([]);
  const [savedToLib, setSavedToLib] = useState(false);
  const [workflow, setWorkflow] = useState<Workflow>("certificate");
  const [preferredForm, setPreferredForm] = useState<"25" | "28" | "25,28" | "auto">("25");
  const [showOther, setShowOther] = useState(false);
  const [showingSample, setShowingSample] = useState(false);
  const [editText, setEditText] = useState("");
  const [edits, setEdits] = useState<string[]>([]);

  const gen = useServerFn(generateCertificate);
  const fetchCert = useServerFn(getCertificate);
  const { edit: editId } = Route.useSearch();
  useEffect(() => {
    if (!editId) return;
    setBusy("Opening certificate…");
    fetchCert({ data: { id: editId } })
      .then((r) => {
        setResult(r);
        setEdits(r.report.source?.edits ?? []);
        setUploaded(r.report.source?.files ?? []);
        setSavedToLib(true);
        if (!r.report.source) toast.error("This older certificate was made before editing was available, so it can't be changed.");
      })
      .catch((e) => toast.error((e as Error).message))
      .finally(() => setBusy(null));
  }, [editId]);
  const [blobUrls, setBlobUrls] = useState<Record<string, string>>({});
  useEffect(() => {
    const urls = [result?.url, result?.sampleUrl].filter((u): u is string => !!u && !blobUrls[u]);
    urls.forEach((u) => {
      fetch(u)
        .then((r) => r.blob())
        .then((b) => {
          const obj = URL.createObjectURL(new Blob([b], { type: "application/pdf" }));
          setBlobUrls((m) => ({ ...m, [u]: obj }));
        })
        .catch(() => setBlobUrls((m) => ({ ...m, [u]: u })));
    });
  }, [result?.url, result?.sampleUrl]);
  const save = useServerFn(saveDocuments);
  const docs = useQuery({ queryKey: ["saved"], queryFn: useServerFn(listSavedDocs) });
  const tpls = useQuery({ queryKey: ["templates"], queryFn: useServerFn(listTemplates) });

  const canRun = insFiles.length || savedIds.length;

  async function run() {
    setResult(null);
    setShowingSample(false);
    setSavedToLib(false);
    setEdits([]);
    try {
      setBusy("Uploading documents…");
      const job = crypto.randomUUID();
      const up: Uploaded[] = [];
      for (const [role, list] of [
        ["request", requestFiles],
        ["insurance", insFiles],
      ] as const) {
        for (const f of list) {
          const path = await uploadFile(`jobs/${job}/${role}-${up.length}-${safeName(f.name)}`, f);
          up.push({ path, name: f.name, mime: f.type || "application/octet-stream", role });
        }
      }
      setUploaded(up);
      setBusy(workflow === "application" ? "Reading documents and assembling the application…" : "Reading documents and filling the certificate…");
      const r = await gen({ data: { requestText, files: up, savedIds, workflow, preferredForm, edits: [] } });
      setResult(r);
      setShowingSample(Boolean(r.report.sample_requested && r.sampleUrl));
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(null);
    }
  }

  async function revise() {
    if (!result || !editText.trim()) return;
    const all = [...edits, editText.trim()];
    const codes = result.report.form_codes ?? [result.report.form_code];
    const form = (codes.includes("25") && codes.includes("28") ? "25,28" : codes.includes("28") ? "28" : codes.includes("25") ? "25" : "auto") as typeof preferredForm;
    const src = result.report.source;
    try {
      setBusy("Applying your changes…");
      const r = await gen({ data: { requestText: src?.requestText ?? requestText, files: src?.files ?? uploaded, savedIds: src?.savedIds ?? savedIds, workflow: result.report.workflow ?? workflow, preferredForm: src?.preferredForm ?? form, edits: all } });
      setResult(r);
      setEdits(all);
      setEditText("");
      setShowingSample(Boolean(r.report.sample_requested && r.sampleUrl));
      toast.success("Changes applied");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(null);
    }
  }

  async function saveInsurance() {
    const files = uploaded.filter((u) => u.role === "insurance").map(({ path, name, mime }) => ({ path, name, mime }));
    if (!files.length) return;
    try {
      await save({ data: { files, label: result?.insured || undefined } });
      setSavedToLib(true);
      docs.refetch();
      toast.success("Saved to your library");
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  function reset() {
    setResult(null);
    setShowingSample(false);
    setEdits([]);
    setEditText("");
    setRequestFiles([]);
    setInsFiles([]);
    setRequestText("");
    setSavedIds([]);
    setUploaded([]);
  }

  if (busy) {
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center gap-5 text-center">
        <div className="h-14 w-14 rounded-full bg-accent animate-breathe" />
        <p className="font-serif text-2xl text-primary">{busy}</p>
        <p className="max-w-sm text-sm text-muted-foreground">
          This usually takes a minute or two. Policies are read carefully so nothing is invented.
        </p>
      </div>
    );
  }

  if (result) {
    const activeUrl = showingSample ? result.sampleUrl : result.url;
    const previewSrc = activeUrl ? blobUrls[activeUrl] ?? null : null;
    return (
      <div>
        <PageTitle
          title={result.report.workflow === "application"
            ? "Commercial application ready"
            : result.report.form_codes?.length === 2
              ? "ACORD 25 + 28 package ready"
              : `ACORD ${result.report.form_code} ready`}
          sub={result.report.summary}
        />
        <div className="mb-6 flex flex-wrap gap-3">
          {activeUrl && (
            <Button asChild>
              <a href={activeUrl} target="_blank" rel="noreferrer" download>
                <Download className="h-4 w-4" /> {showingSample ? "Download sample" : "Download PDF"}
              </a>
            </Button>
          )}
          {result.report.workflow === "certificate" && result.sampleUrl && (
            <Button variant="outline" onClick={() => setShowingSample((value) => !value)}>
              <Stamp className="h-4 w-4" /> {showingSample ? "View issued certificate" : "Create sample"}
            </Button>
          )}
          {uploaded.some((u) => u.role === "insurance") && (
            <Button variant="outline" onClick={saveInsurance} disabled={savedToLib}>
              <BookmarkPlus className="h-4 w-4" /> {savedToLib ? "Saved to library" : "Save these policies"}
            </Button>
          )}
          <Button variant="ghost" onClick={reset}>
            <RotateCcw className="h-4 w-4" /> Start another
          </Button>
        </div>
        <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
          <Panel className="p-0 overflow-hidden">
            {activeUrl ? (
              previewSrc ? (
                <iframe key={previewSrc} title={showingSample ? "Sample certificate preview" : "Document preview"} src={`${previewSrc}#view=FitH&navpanes=0`} className="block h-[85vh] min-h-[900px] w-full bg-card" />
              ) : (
                <p className="flex h-[60vh] items-center justify-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Loading preview…</p>
              )
            ) : (
              <p className="p-6 text-sm text-muted-foreground">Preview unavailable.</p>
            )}
          </Panel>
          <div className="space-y-4">
            <Panel className="p-5">
              <h2 className="mb-1 text-base">Make changes</h2>
              <p className="mb-3 text-sm text-muted-foreground">Tell the assistant what to fix, e.g. "change holder address to 5 Main St" or "remove the umbrella".</p>
              <Textarea value={editText} onChange={(e) => setEditText(e.target.value)} placeholder="Describe the edit…" className="mb-3 min-h-24 bg-background" />
              {!!editId && !result.report.source && (
                <p className="mb-3 rounded-md bg-warning-soft px-3 py-2 text-xs text-warning-foreground">This certificate was made before editing was added, so its original documents weren't linked. Create it again from the New certificate page to edit it.</p>
              )}
              {edits.length > 0 && (
                <ul className="mb-3 space-y-1 text-xs text-muted-foreground">
                  {edits.map((t, i) => <li key={i}>Applied: {t}</li>)}
                </ul>
              )}
              <Button onClick={revise} disabled={!editText.trim() || (!!editId && !result.report.source)} className="w-full">
                <Wand2 className="h-4 w-4" /> Apply changes
              </Button>
            </Panel>
            <ReportView report={result.report} />
          </div>
        </div>
      </div>
    );
  }

  const noForms = tpls.data && tpls.data.length === 0;

  return (
    <div>
      <PageTitle
        title="Create a certificate"
        sub="Start with ACORD 25 or 28. The assistant fills only what the insurance documents support and clearly flags anything missing."
      />
      {noForms && (
        <div className="mb-6 rounded-xl bg-warning-soft px-5 py-4 text-sm text-warning-foreground">
          No blank ACORD forms installed yet — add them on the Forms page before generating.
        </div>
      )}
      <div className="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Button
          type="button"
          variant="outline"
          onClick={() => { setWorkflow("certificate"); setPreferredForm("25"); }}
          className={`h-auto min-h-28 items-start justify-start gap-4 whitespace-normal p-5 text-left shadow-none ${workflow === "certificate" && preferredForm === "25" ? "border-primary bg-secondary" : "bg-card hover:border-primary/50"}`}
        >
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary text-primary-foreground"><ShieldCheck className="h-5 w-5" /></span>
          <span><strong className="block text-base">ACORD 25</strong><span className="mt-1 block text-sm text-muted-foreground">Liability certificate</span></span>
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={() => { setWorkflow("certificate"); setPreferredForm("28"); }}
          className={`h-auto min-h-28 items-start justify-start gap-4 whitespace-normal p-5 text-left shadow-none ${workflow === "certificate" && preferredForm === "28" ? "border-primary bg-secondary" : "bg-card hover:border-primary/50"}`}
        >
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary text-primary-foreground"><Building2 className="h-5 w-5" /></span>
          <span><strong className="block text-base">ACORD 28</strong><span className="mt-1 block text-sm text-muted-foreground">Commercial property evidence</span></span>
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={() => { setWorkflow("certificate"); setPreferredForm("25,28"); }}
          className={`h-auto min-h-28 items-start justify-start gap-4 whitespace-normal p-5 text-left shadow-none sm:col-span-2 lg:col-span-1 ${workflow === "certificate" && preferredForm === "25,28" ? "border-primary bg-secondary" : "bg-card hover:border-primary/50"}`}
        >
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary text-primary-foreground"><Files className="h-5 w-5" /></span>
          <span><strong className="block text-base">ACORD 25 + 28</strong><span className="mt-1 block text-sm text-muted-foreground">Liability and commercial property</span></span>
        </Button>
      </div>
      <div className="mb-7 border-b border-border pb-5">
        <p className="text-sm text-muted-foreground">Choose the certificate form you want. ACORD 101 is added automatically when more space is needed.</p>
      </div>
      <div className="grid gap-5 md:grid-cols-2">
        <Panel>
          <h2 className="mb-1 text-lg">1. The request</h2>
          <p className="mb-4 text-sm text-muted-foreground">Paste the email or upload the request. Optional — if left blank, the certificate goes to the mortgagee in the documents.</p>
          <Textarea
            value={requestText}
            onChange={(e) => setRequestText(e.target.value)}
            placeholder="e.g. Please issue a COI to ABC Holdings LLC, 12 Main St… naming them additional insured on a primary & non-contributory basis…"
            className="mb-4 min-h-36 bg-background"
          />
          <DropZone label="Upload request" hint="PDF, image, email, or Outlook message" files={requestFiles} onChange={setRequestFiles} />
        </Panel>
        <Panel>
          <h2 className="mb-1 text-lg">2. Insurance documents</h2>
          <p className="mb-4 text-sm text-muted-foreground">Policies, binders, proposals, quotes, endorsements.</p>
          <DropZone label="Upload documents" hint="These are the source of truth" files={insFiles} onChange={setInsFiles} />
          {docs.data && docs.data.length > 0 && (
            <div className="mt-6">
              <p className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">From your library</p>
              <ul className="max-h-48 space-y-1 overflow-auto">
                {docs.data.map((d) => (
                  <li key={d.id}>
                    <label className="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 text-sm hover:bg-muted">
                      <Checkbox
                        checked={savedIds.includes(d.id)}
                        onCheckedChange={(c) =>
                          setSavedIds((s) => (c ? [...s, d.id] : s.filter((x) => x !== d.id)))
                        }
                      />
                      <span className="truncate">{d.name}</span>
                      {d.label && <span className="ml-auto truncate text-xs text-muted-foreground">{d.label}</span>}
                    </label>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </Panel>
      </div>
      <div className="mt-8 flex justify-end">
        <Button size="lg" onClick={run} disabled={!canRun || !!noForms}>
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
          {workflow === "application" ? "Create application" : "Generate certificate"}
        </Button>
      </div>
    </div>
  );
}
