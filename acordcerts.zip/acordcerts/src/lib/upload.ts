import { supabase } from "@/integrations/supabase/client";
import { createUploadUrl } from "./cert.functions";

export function safeName(name: string) {
  return name.replace(/[^A-Za-z0-9._\-]/g, "_").slice(-120);
}

export async function uploadFile(path: string, file: File) {
  const { path: p, token } = await createUploadUrl({ data: { path } });
  const { error } = await supabase.storage.from("acord").uploadToSignedUrl(p, token, file, {
    contentType: file.type || "application/octet-stream",
  });
  if (error) throw new Error(error.message);
  return p;
}
